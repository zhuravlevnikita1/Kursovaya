import java.sql.SQLException;

public class Users {
    public static String name;
    public static String lastname;
    public static String patronymic;
    public static String phone_num;
    public static String email;
    public static String password;

    public static void setName(String name) {
        Users.name = name;
    }

    public static void setLastname(String lastname) {
        Users.lastname = lastname;
    }

    public static void setPatronymic(String patronymic) {
        Users.patronymic = patronymic;
    }

    public static void setPhone_num(String phone_num) {
        Users.phone_num = phone_num;
    }

    public static void setEmail(String email) {
        Users.email = email;
    }

    public static void setPassword(String password) {
        Users.password = password;
    }


    public static void addNewUser () throws SQLException {
        Database.addUser(getName(), getLastname(), getPatronymic(),
                getPhone_num(), getEmail(), getPassword());
    }

    public static boolean search_by_values (String email, String password) throws SQLException {
        return Database.Search(email, password);
    }

    public static String getName() {
        return name;
    }

    public static String getLastname() {
        return lastname;
    }

    public static String getPatronymic() {
        return patronymic;
    }

    public static String getPhone_num() {
        return phone_num;
    }

    public static String getEmail() {
        return email;
    }

    public static String getPassword() {
        return password;
    }
}
