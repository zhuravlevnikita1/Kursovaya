import java.sql.ResultSet;
import java.sql.SQLException;

public class Products {
    public static String name;
    public static String description;
    public static Double price;
    public static int avaibility;
    public static int id;

    public static void addNewProduct (String name, String desc, String price, String avail) throws SQLException {
        Database.addProduct(name, desc, price, avail);
    }

    public static void delExistProduct (String name) throws SQLException {
        Database.delProduct(name);
    }

    public static String getName() {
        return name;
    }

    public static ResultSet getDescription(String name) throws SQLException {
        return Database.getDescription("goods", name);
    }

    public static ResultSet getPrice(String name) throws SQLException {
        return Database.getPrice("goods", name);
    }

    public static ResultSet getAvaibility(String name) throws SQLException {
        return Database.getAvaibility("goods", name);
    }

    public static int getId(String description) throws SQLException {
        return id;
    }

    public static void setId(int id) {
        Products.id = id;
    }

    public static ResultSet getNamesGoods() throws SQLException {
        return Database.getNames("goods");
    }
}
