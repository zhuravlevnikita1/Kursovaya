import javax.swing.*;
import java.awt.*;
import java.sql.SQLException;

public class MainFrame extends JFrame {
    public MainFrame() throws HeadlessException, SQLException {
        super("�����.���");
        JTabbedPane tabbedPane = new JTabbedPane();
        tabbedPane.addTab("�������", new CatalogPanel());
        setLayout(new BorderLayout());
        add(tabbedPane);
    }
}
