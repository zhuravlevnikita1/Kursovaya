package Authorization;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class AuthorizationDialog extends JDialog {
    private static JFrame dialogFrame = new JFrame();
    private static int event = 0;

    public AuthorizationDialog() {
        super(dialogFrame, "�����.���.�����������", true);
        setSize(400, 130);
        setLocationRelativeTo(null);
        setLayout(new FlowLayout());

        JButton entranceButton = new JButton("����� � �������");
        entranceButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                event = 1;
                setVisible(false);
            }
        });

        JButton regButton = new JButton("������� �������");
        regButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                event = 2;
                setVisible(false);
            }
        });

        JButton guestButton = new JButton("�������� �����");
        guestButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });

        JPanel panel0 = new JPanel();
        JPanel panel1 = new JPanel();
        JPanel panel2 = new JPanel();
        JPanel panel3 = new JPanel();

        panel1.setSize(75,75);
        panel2.setSize(75,75);
        panel3.setSize(75,75);


        panel1.add(entranceButton);
        panel2.add(regButton);
        panel3.add(guestButton);

        add(panel1);
        add(panel2);
        add(panel3);
    }

    public static int getEvent() {
        return event;
    }

    public static void setEvent(int event) {
        AuthorizationDialog.event = event;
    }
}
