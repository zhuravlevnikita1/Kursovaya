import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;

public class DelDialog extends JDialog {
    private static String  name;
    private static JFrame dialogFrame = new JFrame();
    private static boolean flag = false;
    public DelDialog() {
        super(dialogFrame, "���������� ������", true);
        setSize(300, 150);
        setLocationRelativeTo(null);
        setLayout(new FlowLayout());

        JPanel panel1 = new JPanel(new FlowLayout());
        JButton yesButton = new JButton("��");
        JButton noButton = new JButton("������");
        panel1.add(noButton);
        panel1.add(new JLabel("            " +
                "                               " +
                ""));
        panel1.add(yesButton);

        noButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });

        yesButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                setName(name);
                try {
                    Products.delExistProduct(name);
                } catch (SQLException ex) {
                    throw new RuntimeException(ex);
                }

                setFlag(true);
                dispose();
            }
        });

        add(new JLabel("                                    "));
        add(new JLabel("�� �������, ��� ������ ������� ���� �����?"));
        add(new JLabel("                                    "));
        add(panel1);
    }

    public String getName(){
        return name;
    }

    public void setName(String name) {
        DelDialog.name = name;
    }

    public static boolean isFlag() {
        return flag;
    }

    public static void setFlag(boolean flag) {
        DelDialog.flag = flag;
    }
}
